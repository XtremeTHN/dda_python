from glob import glob
from pystyle import Colorate, Colors
import os

def edit_main(arguments,printf,parser):
    if arguments.editor != 'nano':
        printf('WARNING','If the custom editor is not installed, maybe will appear errors', Colors.red_to_blue,quiet_arg=arguments.quiet)
        printf('OVERRIDE',f'Using custom editor: {arguments.editor}', Colors.blue_to_red,quiet_arg=arguments.quiet)
    if arguments.edit != None:
        if arguments.file == None:
            printf('ERROR','You need to specify the file you want to edit',Colors.red_to_blue,quiet_arg=arguments.quiet)
            sys.exit(2)
        if arguments.edit != '':
            printf('INFO',f'Browsing in folder {arguments.edit}...',Colors.blue_to_red,quiet_arg=arguments.quiet)
            if os.path.exists(os.path.join('/home',os.getenv('USER'), '.config', arguments.edit)):
                printf('DEBUG','Folder exists',Colors.blue_to_red,debug_arg=arguments.debug,quiet_arg=arguments.quiet)
                os.system(f'{arguments.editor} {os.path.join("/home",os.getenv("USER"),".config",arguments.edit,arguments.file)}')
                printf('INFO', 'Exiting...',Colors.blue_to_red,quiet_arg=arguments.quiet)

            else:
                printf('ERROR',f'No folder named {arguments.edit} in .config',Colors.red_to_blue)
                sys.exit(1)
